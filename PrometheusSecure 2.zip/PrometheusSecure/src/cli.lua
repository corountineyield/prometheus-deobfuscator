#!/usr/bin/env lua

local Deobfuscator = require("src.core.deobfuscator")

local function print_usage()
	print("Prometheus Deobfuscator CLI")
	print("Usage: lua src/cli.lua <input_file> [options]")
	print()
	print("Options:")
	print("  --output FILE          Output file (default: input_deobfuscated.lua)")
	print("  --keys K6,K7,K44,K8   PRNG keys for string decryption (comma-separated)")
	print("  --verbose              Show detailed progress")
	print("  --help                 Show this message")
	print()
end

local function parse_args(args)
	local input_file = nil
	local output_file = nil
	local keys = nil
	local verbose = false
	
	local i = 1
	while i <= #args do
		local arg = args[i]
		
		if arg == "--help" then
			print_usage()
			os.exit(0)
		elseif arg == "--output" then
			i = i + 1
			output_file = args[i]
		elseif arg == "--keys" then
			i = i + 1
			keys = args[i]
		elseif arg == "--verbose" then
			verbose = true
		elseif not arg:match("^%-") then
			input_file = arg
		end
		
		i = i + 1
	end
	
	return input_file, output_file, keys, verbose
end

local function parse_keys(keys_str)
	if not keys_str then
		return nil, nil, nil, nil
	end
	
	local parts = {}
	for part in string.gmatch(keys_str, "[^,]+") do
		table.insert(parts, tonumber(part))
	end
	
	if #parts == 4 then
		return parts[1], parts[2], parts[3], parts[4]
	end
	
	return nil, nil, nil, nil
end

local function main(...)
	local args = {...}
	
	if #args == 0 then
		print_usage()
		os.exit(1)
	end
	
	local input_file, output_file, keys_str, verbose = parse_args(args)
	
	if not input_file then
		print("ERROR: Input file not specified")
		print_usage()
		os.exit(1)
	end
	
	local file = io.open(input_file, "r")
	if not file then
		print("ERROR: Cannot open file: " .. input_file)
		os.exit(1)
	end
	
	local obfuscated_code = file:read("*a")
	file:close()
	
	local deob = Deobfuscator.new()
	deob:load_code(obfuscated_code)
	
	local result = deob:deobfuscate_full()
	
	if keys_str then
		local k6, k7, k44, k8 = parse_keys(keys_str)
		if k6 then
			print()
			print("Attempting string decryption with provided keys...")
			deob:layer_4_decrypt_strings(k6, k7, k44, k8)
			result = deob:get_current_code()
		end
	end
	
	output_file = output_file or input_file:gsub("%.lua$", "_deobfuscated.lua")
	
	local out = io.open(output_file, "w")
	if not out then
		print("ERROR: Cannot write to: " .. output_file)
		os.exit(1)
	end
	
	out:write(result)
	out:close()
	
	print()
	print("✓ Deobfuscated code written to: " .. output_file)
	print()
end

main(...)
