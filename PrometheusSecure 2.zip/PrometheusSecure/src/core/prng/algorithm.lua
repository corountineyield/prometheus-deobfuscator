local PRNG = {}

local floor = math.floor

function PRNG.primitive_root_257(idx)
	local g, m, d = 1, 128, 2 * idx + 1
	repeat
		g = g * g * (d >= m and 3 or 1) % 257
		m = m / 2
		d = d % m
	until m < 1
	return g
end

function PRNG.create_decryptor(secret_key_6, secret_key_7, secret_key_44, secret_key_8)
	local param_mul_8 = PRNG.primitive_root_257(secret_key_7)
	local param_mul_45 = secret_key_6 * 4 + 1
	local param_add_45 = secret_key_44 * 2 + 1

	local state_45 = 0
	local state_8 = 2
	local prev_values = {}

	local function set_seed(seed_53)
		state_45 = seed_53 % 35184372088832
		state_8 = seed_53 % 255 + 2
		prev_values = {}
	end

	local function get_random_32()
		state_45 = (state_45 * param_mul_45 + param_add_45) % 35184372088832
		repeat
			state_8 = state_8 * param_mul_8 % 257
		until state_8 ~= 1
		
		local r = state_8 % 32
		local n = floor(state_45 / 2 ^ (13 - (state_8 - r) / 32)) % 2 ^ 32 / 2 ^ r
		return floor(n % 1 * 2 ^ 32) + floor(n)
	end

	local function get_next_pseudo_random_byte()
		if #prev_values == 0 then
			local rnd = get_random_32()
			local low_16 = rnd % 65536
			local high_16 = (rnd - low_16) / 65536
			local b1 = low_16 % 256
			local b2 = (low_16 - b1) / 256
			local b3 = high_16 % 256
			local b4 = (high_16 - b3) / 256
			prev_values = { b1, b2, b3, b4 }
		end
		return table.remove(prev_values)
	end

	local function decrypt_string(encrypted_str, seed)
		set_seed(seed)
		local len = string.len(encrypted_str)
		local result = {}
		local prevVal = secret_key_8
		
		for i = 1, len do
			local encrypted_byte = string.byte(encrypted_str, i)
			local random_byte = get_next_pseudo_random_byte()
			local decrypted_byte = (encrypted_byte + random_byte + prevVal) % 256
			result[i] = string.char(decrypted_byte)
			prevVal = decrypted_byte
		end
		
		return table.concat(result)
	end

	return {
		decrypt = decrypt_string,
		set_seed = set_seed,
		param_mul_8 = param_mul_8,
		param_mul_45 = param_mul_45,
		param_add_45 = param_add_45,
		secret_key_8 = secret_key_8
	}
end

return PRNG
