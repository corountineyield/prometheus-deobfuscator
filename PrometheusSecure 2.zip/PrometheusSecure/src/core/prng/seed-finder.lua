local PRNG = require("src.core.prng.algorithm")

local SeedFinder = {}

local LUA_KEYWORDS = {
	["local"] = true, ["function"] = true, ["return"] = true,
	["if"] = true, ["then"] = true, ["else"] = true, ["elseif"] = true,
	["end"] = true, ["for"] = true, ["do"] = true, ["while"] = true,
	["repeat"] = true, ["until"] = true, ["break"] = true, ["and"] = true,
	["or"] = true, ["not"] = true, ["in"] = true, ["print"] = true,
	["table"] = true, ["string"] = true, ["math"] = true, ["pairs"] = true,
	["ipairs"] = true, ["next"] = true, ["type"] = true, ["tostring"] = true,
	["tonumber"] = true, ["setmetatable"] = true, ["getmetatable"] = true,
	["rawget"] = true, ["rawset"] = true, ["true"] = true, ["false"] = true,
	["nil"] = true
}

function SeedFinder.extract_numeric_constants(code)
	local constants = {}
	local seen = {}
	
	for num_str in string.gmatch(code, "%d+") do
		local num = tonumber(num_str)
		if num and not seen[num] then
			seen[num] = true
			table.insert(constants, num)
		end
	end
	
	return constants
end

function SeedFinder.extract_seeds_from_decrypt_calls(code)
	local seeds = {}
	local seen = {}
	
	for seed_str in string.gmatch(code, "DECRYPT%([^,]+,%s*(%d+)") do
		local seed = tonumber(seed_str)
		if seed and not seen[seed] then
			seen[seed] = true
			table.insert(seeds, seed)
		end
	end
	
	return seeds
end

function SeedFinder.count_keywords(text)
	local count = 0
	for word in string.gmatch(text, "%a+") do
		if LUA_KEYWORDS[word] then
			count = count + 1
		end
	end
	return count
end

function SeedFinder.test_seed(encrypted_str, seed, secret_key_6, secret_key_7, secret_key_44, secret_key_8)
	local decryptor = PRNG.create_decryptor(secret_key_6, secret_key_7, secret_key_44, secret_key_8)
	local decrypted = decryptor.decrypt(encrypted_str, seed)
	
	local keyword_count = SeedFinder.count_keywords(decrypted)
	local printable_ratio = 0
	local printable = 0
	
	for i = 1, #decrypted do
		local byte = string.byte(decrypted, i)
		if (byte >= 32 and byte <= 126) or byte == 9 or byte == 10 or byte == 13 then
			printable = printable + 1
		end
	end
	
	printable_ratio = printable / #decrypted
	
	local confidence = (keyword_count * 10) + (printable_ratio * 5)
	
	return {
		decrypted = decrypted,
		confidence = confidence,
		keyword_count = keyword_count,
		printable_ratio = printable_ratio
	}
end

function SeedFinder.find_best_seed(encrypted_strings, seeds, secret_key_6, secret_key_7, secret_key_44, secret_key_8)
	local best_seeds = {}
	
	for _, seed in ipairs(seeds) do
		local total_confidence = 0
		
		for _, encrypted in ipairs(encrypted_strings) do
			local result = SeedFinder.test_seed(encrypted, seed, secret_key_6, secret_key_7, secret_key_44, secret_key_8)
			total_confidence = total_confidence + result.confidence
		end
		
		table.insert(best_seeds, {
			seed = seed,
			confidence = total_confidence / #encrypted_strings
		})
	end
	
	table.sort(best_seeds, function(a, b) return a.confidence > b.confidence end)
	
	return best_seeds[1]
end

return SeedFinder
