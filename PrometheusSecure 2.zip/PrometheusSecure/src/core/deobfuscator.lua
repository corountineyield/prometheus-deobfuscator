
local Unwrap = require("src.core.layers.01-unwrap")
local SplitStrings = require("src.core.layers.02-split-strings")
local ConstantArray = require("src.core.layers.03-constant-array")
local DecryptStrings = require("src.core.layers.04-decrypt-strings")
local ProxifyLocals = require("src.core.layers.05-proxified")
local Vmify = require("src.core.layers.06-vmify")
local AntiTamper = require("src.core.layers.08-anti-tamper")
local NumberExpressions = require("src.core.layers.09-number-expressions")
local Watermark = require("src.core.layers.10-watermark")
local VariadicArgs = require("src.core.layers.11-variadic-args")

local Deobfuscator = {}

function Deobfuscator.new()
        local instance = {
                original_code = "",
                current_code = "",
                history = {},
                statistics = {
                        wrappings_removed = 0,
                        strings_rejoined = 0,
                        constants_decoded = 0,
                        strings_decrypted = 0,
                        proxies_reversed = 0,
                        vmified = false,
                        watermark_detected = false,
                        anti_tamper_detected = false,
                        variadic_found = 0,
                        passes_completed = 0
                },
                detected_obfuscation_level = "unknown",
                detected_presets = {},
                analysis_results = {}
        }
        return setmetatable(instance, { __index = Deobfuscator })
end

function Deobfuscator.load_code(self, code)
        self.original_code = code
        self.current_code = code
        self.history = { code }
end

function Deobfuscator.detect_obfuscation(self)
        print("Analyzing obfuscation patterns...")
        
        local split_count = 0
        for _ in string.gmatch(self.current_code, '"[^"]*"%s*%.%.%s*"[^"]*"') do
                split_count = split_count + 1
        end
        
        local indicators = {
                function_wrappers = Unwrap.detect_wrapper(self.current_code),
                split_strings = split_count,
                constant_arrays = (ConstantArray.find_constant_array(self.current_code) ~= nil),
                encrypted_strings = (#DecryptStrings.find_encrypted_strings(self.current_code) > 0),
                proxified_code = (ProxifyLocals.find_proxified_locals(self.current_code) and true or false),
                vmified_code = (Vmify.is_vmified(self.current_code)),
                watermark = Watermark.detect(self.current_code),
                anti_tamper = AntiTamper.detect(self.current_code),
                variadic_args = VariadicArgs.detect(self.current_code)
        }
        
        self.analysis_results = indicators
        
        local obfuscation_score = 0
        if indicators.function_wrappers then obfuscation_score = obfuscation_score + 1 end
        if indicators.split_strings > 0 then obfuscation_score = obfuscation_score + 1 end
        if indicators.constant_arrays then obfuscation_score = obfuscation_score + 1 end
        if indicators.encrypted_strings then obfuscation_score = obfuscation_score + 2 end
        if indicators.proxified_code then obfuscation_score = obfuscation_score + 1 end
        if indicators.vmified_code then obfuscation_score = obfuscation_score + 3 end
        
        if obfuscation_score <= 1 then
                self.detected_obfuscation_level = "Minify"
        elseif obfuscation_score <= 3 then
                self.detected_obfuscation_level = "Weak"
        elseif obfuscation_score <= 5 then
                self.detected_obfuscation_level = "Medium"
        else
                self.detected_obfuscation_level = "Strong"
        end
        
        print("  Detected obfuscation level: " .. self.detected_obfuscation_level)
        if indicators.watermark then
                print("  ✓ Watermark detected")
                self.statistics.watermark_detected = true
        end
        if indicators.anti_tamper then
                print("  ✓ Anti-tamper detection code found")
                self.statistics.anti_tamper_detected = true
        end
        if indicators.variadic_args then
                print("  ✓ Variadic arguments detected")
                self.statistics.variadic_found = 1
        end
        print()
end

function Deobfuscator.layer_1_unwrap(self)
        print("Layer 1: Unwrapping function wrappers...")
        
        local unwrapped, iterations = Unwrap.unwrap_all(self.current_code)
        self.statistics.wrappings_removed = iterations
        
        if iterations > 0 then
                print("  ✓ Removed " .. iterations .. " wrapper layer(s)")
                self.current_code = unwrapped
                table.insert(self.history, unwrapped)
        else
                print("  - No function wrappers found")
        end
        
        return iterations > 0
end

function Deobfuscator.layer_2_split_strings(self)
        print("Layer 2: Rejoining split strings...")
        
        local original_len = #self.current_code
        local rejoined = SplitStrings.rejoin_all_fragments(self.current_code)
        
        if original_len ~= #rejoined then
                local reduction = math.floor((original_len - #rejoined) / 10)
                print("  ✓ Code reduced by ~" .. reduction .. " fragments")
                self.current_code = rejoined
                table.insert(self.history, rejoined)
                self.statistics.strings_rejoined = reduction
                return true
        else
                print("  - No split strings found")
        end
        
        return false
end

function Deobfuscator.layer_3_constant_array(self)
        print("Layer 3: Extracting and decoding constant array...")
        
        local array_name, array_content = ConstantArray.find_constant_array(self.current_code)
        
        if not array_name then
                print("  - No constant array found")
                return false
        end
        
        print("  ✓ Found array: " .. array_name)
        
        local elements = ConstantArray.extract_array_elements(array_content)
        print("  ✓ Elements in array: " .. #elements)

        local alphabet = ConstantArray.find_base64_lookup(self.current_code)
        local decoded = ConstantArray.decode_elements(elements, alphabet)
        
        local offset = ConstantArray.find_wrapper_offset(self.current_code)
        print("  ✓ Wrapper offset: " .. offset)
        
        local inlined = ConstantArray.inline_constants(self.current_code, array_name, decoded, offset)
        
        self.statistics.constants_decoded = #elements
        self.current_code = inlined
        table.insert(self.history, inlined)
        
        return true
end

function Deobfuscator.layer_4_decrypt_strings(self, secret_key_6, secret_key_7, secret_key_44, secret_key_8)
        print("Layer 4: Decrypting strings with PRNG...")
        
        if not secret_key_6 or not secret_key_7 or not secret_key_44 or not secret_key_8 then
                print("  - PRNG keys not provided, attempting auto-detection...")
                
                local encrypted = DecryptStrings.find_encrypted_strings(self.current_code)
                if #encrypted > 0 then
                        local results = DecryptStrings.find_keys_by_brute_force(encrypted, self.current_code)
                        
                        if #results > 0 then
                                local best = results[1]
                                print("  ✓ Auto-detected keys with " .. string.format("%.2f", best.confidence * 100) .. "% confidence")
                                secret_key_6, secret_key_7, secret_key_44, secret_key_8 = unpack(best.keys)
                        else
                                print("  - Could not auto-detect keys")
                                return false
                        end
                else
                        print("  - No encrypted strings found")
                        return false
                end
        end
        
        local decrypted_code, count = DecryptStrings.decrypt_all(
                self.current_code,
                secret_key_6, secret_key_7, secret_key_44, secret_key_8
        )
        
        self.statistics.strings_decrypted = count
        
        if count > 0 then
                print("  ✓ Decrypted " .. count .. " strings")
                self.current_code = decrypted_code
                table.insert(self.history, decrypted_code)
                return true
        else
                print("  - No encrypted strings found")
        end
        
        return false
end

function Deobfuscator.layer_5_proxified_locals(self)
        print("Layer 5: Reversing ProxifyLocals metatable indirection...")
        
        local reversed = ProxifyLocals.reverse_all(self.current_code)
        
        if reversed ~= self.current_code then
                print("  ✓ Reversed proxified locals")
                self.current_code = reversed
                table.insert(self.history, reversed)
                self.statistics.proxies_reversed = 1
                return true
        else
                print("  - No proxified locals found")
        end
        
        return false
end

function Deobfuscator.layer_6_vmify(self)
        print("Layer 6: Analyzing VM bytecode...")
        
        local analysis = Vmify.analyze(self.current_code)
        
        if analysis and analysis.is_vmified then
                print("  ✓ VM bytecode detected!")
                print("    Found " .. analysis.bytecode_arrays .. " bytecode array(s)")
                self.statistics.vmified = true
                
                local extracted = Vmify.devirtualize(self.current_code)
                self.current_code = extracted
                table.insert(self.history, extracted)
                self.vmify_analysis = analysis
                return true
        else
                print("  - No VM bytecode detected")
        end
        
        return false
end

function Deobfuscator.layer_8_anti_tamper(self)
        print("Layer 8: Removing anti-tamper checks...")
        
        if AntiTamper.detect(self.current_code) then
                local checks = AntiTamper.find_checks(self.current_code)
                print("  ✓ Found " .. #checks .. " anti-tamper check(s)")
                
                local cleaned = AntiTamper.reverse_all(self.current_code)
                if cleaned ~= self.current_code then
                        self.current_code = cleaned
                        table.insert(self.history, cleaned)
                        return true
                end
        else
                print("  - No anti-tamper code found")
        end
        
        return false
end

function Deobfuscator.layer_9_number_expressions(self)
        print("Layer 9: Simplifying number expressions...")
        
        if NumberExpressions.detect(self.current_code) then
                print("  ✓ Number expressions detected")
                
                local simplified = NumberExpressions.reverse_all(self.current_code)
                if simplified ~= self.current_code then
                        self.current_code = simplified
                        table.insert(self.history, simplified)
                        return true
                end
        else
                print("  - No number expressions found")
        end
        
        return false
end

function Deobfuscator.layer_10_watermark(self)
        print("Layer 10: Removing watermark metadata...")
        
        if Watermark.detect(self.current_code) then
                local marks = Watermark.find_watermark(self.current_code)
                print("  ✓ Found " .. #marks .. " watermark marker(s)")
                
                local cleaned = Watermark.remove_all(self.current_code)
                if cleaned ~= self.current_code then
                        self.current_code = cleaned
                        table.insert(self.history, cleaned)
                        return true
                end
        else
                print("  - No watermark detected")
        end
        
        return false
end

function Deobfuscator.layer_11_variadic_args(self)
        print("Layer 11: Analyzing variadic arguments...")
        
        if VariadicArgs.detect(self.current_code) then
                local analysis = VariadicArgs.analyze_variadic_usage(self.current_code)
                print("  ✓ Found " .. analysis.variadic_only .. " variadic function(s)")
                
                local marked = VariadicArgs.mark_functions_using_args(self.current_code)
                if marked ~= self.current_code then
                        self.current_code = marked
                        table.insert(self.history, marked)
                        return true
                end
        else
                print("  - No variadic arguments found")
        end
        
        return false
end

function Deobfuscator.export_vmify_analysis(self, output_path)
        if not self.vmify_analysis then
                return false
        end
        return Vmify.export_analysis(self.current_code, output_path)
end

function Deobfuscator.deobfuscate_full(self)
        print("================================================================================")
        print("PROMETHEUS DEOBFUSCATOR - FULL PIPELINE (11 LAYERS)")
        print("================================================================================")
        print()
        
        if not self.original_code or #self.original_code == 0 then
                print("ERROR: No code loaded")
                return false
        end
        
        print("Starting deobfuscation...")
        print("Original code size: " .. #self.original_code .. " bytes")
        print()

        self:detect_obfuscation()
        
        self:layer_1_unwrap()
        print()
        self:layer_2_split_strings()
        print()
        self:layer_3_constant_array()
        print()
        self:layer_4_decrypt_strings()
        print()
        self:layer_5_proxified_locals()
        print()
        self:layer_6_vmify()
        print()
        self:layer_8_anti_tamper()
        print()
        self:layer_9_number_expressions()
        print()
        self:layer_10_watermark()
        print()
        self:layer_11_variadic_args()
        
        print()
        print("================================================================================")
        print("DEOBFUSCATION STATISTICS")
        print("================================================================================")
        print("Detected preset: " .. self.detected_obfuscation_level)
        print("Wrapping layers removed: " .. self.statistics.wrappings_removed)
        print("Strings rejoined: " .. self.statistics.strings_rejoined)
        print("Constants decoded: " .. self.statistics.constants_decoded)
        print("Strings decrypted: " .. self.statistics.strings_decrypted)
        print("Proxies reversed: " .. self.statistics.proxies_reversed)
        print("Vmified code: " .. (self.statistics.vmified and "YES" or "NO"))
        print("Watermark detected: " .. (self.statistics.watermark_detected and "YES" or "NO"))
        print("Anti-tamper detected: " .. (self.statistics.anti_tamper_detected and "YES" or "NO"))
        print("Variadic functions: " .. self.statistics.variadic_found)
        print()
        print("Original size: " .. #self.original_code .. " bytes")
        print("Final size: " .. #self.current_code .. " bytes")
        print("Reduction: " .. math.floor((1 - (#self.current_code / #self.original_code)) * 100) .. "%")
        print()
        
        return self.current_code
end

function Deobfuscator.get_current_code(self)
        return self.current_code
end

function Deobfuscator.get_history(self)
        return self.history
end

function Deobfuscator.get_statistics(self)
        return self.statistics
end

function Deobfuscator.get_analysis(self)
        return self.analysis_results
end

return Deobfuscator
