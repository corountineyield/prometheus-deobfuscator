local SplitStrings = {}

function SplitStrings.rejoin_string_concat(code)
        local count = 0
        local result = code
        local max_iterations = 8000
        
        while count < max_iterations do
                local new_result = result:gsub('"([^"]*)"\\s*%.%.\\s*"([^"]*)"', function(a, b)
                        return '"' .. a .. b .. '"'
                end, 1)
                
                if new_result == result then
                        break
                end
                result = new_result
                count = count + 1
        end
        
        return result
end

function SplitStrings.rejoin_single_quote_concat(code)
        local count = 0
        local result = code
        local max_iterations = 8000
        
        while count < max_iterations do
                local new_result = result:gsub("'([^']*)'%s*%.%.%s*'([^']*)'", function(a, b)
                        return "'" .. a .. b .. "'"
                end, 1)
                
                if new_result == result then
                        break
                end
                result = new_result
                count = count + 1
        end
        
        return result
end

function SplitStrings.rejoin_table_concat(code)
        local count = 0
        local max_iterations = 2000
        
        while count < max_iterations do
                local matches = 0
                local new_code = code:gsub(
                        'table%.concat%s*%(%s*%{%s*(.-?)%s*%}%s*%)',
                        function(content)
                                matches = matches + 1
                                local parts = {}
                                for part in content:gmatch('"([^"]*)"') do
                                        table.insert(parts, part)
                                end
                                for part in content:gmatch("'([^']*)'") do
                                        if not table.concat(parts):find(part) then
                                                table.insert(parts, part)
                                        end
                                end
                                if #parts > 0 then
                                        return '"' .. table.concat(parts) .. '"'
                                end
                                return content
                        end,
                        1
                )
                
                if matches == 0 or new_code == code then
                        break
                end
                code = new_code
                count = count + 1
        end
        
        return code
end

function SplitStrings.rejoin_string_sub(code)
        local count = 0
        
        while count < 200 do
                local new_code = code:gsub(
                        '(["\'].-["\'])%s*:%s*sub%s*%([^)]+%)%s*%.%.%s*(["\'].-["\'])%s*:%s*sub%s*%([^)]+%)',
                        function(str1, str2)
                                return str1
                        end,
                        1
                )
                
                if new_code == code then
                        break
                end
                code = new_code
                count = count + 1
        end
        
        return code
end

function SplitStrings.rejoin_brackets_concat(code)
        local count = 0
        local max_iterations = 1000
        
        while count < max_iterations do
                local new_code = code:gsub('%[(%d+)%]%s*%.%.%s*%[(%d+)%]', function(a, b)
                        return '[' .. tostring(tonumber(a) + tonumber(b)) .. ']'
                end, 1)
                
                if new_code == code then
                        break
                end
                code = new_code
                count = count + 1
        end
        
        return code
end

function SplitStrings.detect_split_patterns(code)
        local patterns = {
                string_concat = (code:match('"[^"]*"%s*%.%.%s*"[^"]*"') and 1 or 0),
                table_concat = (code:match('table%.concat%s*%(%s*%{') and 1 or 0),
                string_sub = (code:match('["\'].-["\']%s*:%s*sub') and 1 or 0),
                brackets = (code:match('%[%d+%]%s*%.%.%s*%[%d+%]') and 1 or 0)
        }
        return patterns
end

function SplitStrings.count_split_operations(code)
        local count = 0
        for _ in code:gmatch('"[^"]*"%s*%.%.%s*"[^"]*"') do
                count = count + 1
        end
        for _ in code:gmatch('table%.concat%s*%(%s*%{') do
                count = count + 1
        end
        return count
end

function SplitStrings.decode_escape_sequences(code)
        -- NOTE: Escape sequences in Lua source code (like \072 for octal)
        -- are automatically interpreted by Lua's parser when the code is executed.
        -- We should NOT try to manually decode them in the deobfuscator
        -- because they are already valid Lua and will work correctly.
        -- This function is kept for compatibility but does minimal transformation.
        
        -- Only handle escape sequences that are part of comments/strings being processed
        -- Don't touch literal \ddd sequences - Lua will interpret them correctly
        
        return code
end

function SplitStrings.rejoin_all_fragments(code)
        code = SplitStrings.rejoin_string_concat(code)
        code = SplitStrings.rejoin_single_quote_concat(code)
        code = SplitStrings.rejoin_table_concat(code)
        code = SplitStrings.rejoin_string_sub(code)
        code = SplitStrings.rejoin_brackets_concat(code)
        code = SplitStrings.decode_escape_sequences(code)
        return code
end

return SplitStrings
