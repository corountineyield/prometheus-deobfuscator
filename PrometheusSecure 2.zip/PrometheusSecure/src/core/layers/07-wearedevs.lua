local Base64 = require("src.core.utils.base64")

local WeareDevsLayer = {}

function WeareDevsLayer.detect(code)
	if code:find('return%s*%(%s*function%s*%(%.%.%.%)') and 
	   code:find('local%s+%w+%s*=%s*%{') then
		if code:find('"[%w%+/%=]{20,}"') then
			return true
		end
	end
	if code:match("local%s+%w+%s*=%s*%{[%s%w%+/%=%,\"']+%}") then
		return true
	end
	return false
end

function WeareDevsLayer.detect_xor_key(code)
	local keys_found = {}
	
	for key in string.gmatch(code, "XOR%s*%(%s*(%d+)%s*%)") do
		table.insert(keys_found, tonumber(key))
	end
	
	for key in string.gmatch(code, "bit%.bxor%s*%(%s*(%d+)") do
		table.insert(keys_found, tonumber(key))
	end
	
	return keys_found
end

function WeareDevsLayer.find_array_name(code)
	return code:match('local%s+(%w+)%s*=%s*%{')
end

function WeareDevsLayer.find_all_arrays(code)
	local arrays = {}
	for name in string.gmatch(code, 'local%s+(%w+)%s*=%s*%{[^}]*%}') do
		table.insert(arrays, name)
	end
	return arrays
end

function WeareDevsLayer.extract_base64_strings(code, array_name)
	if not array_name then return {} end
	
	local strings = {}
	
	local array_pattern = 'local%s+' .. array_name .. '%s*=%s*%{([^}]+)%}'
	local array_content = code:match(array_pattern)
	
	if array_content then
		for str in array_content:gmatch('"([^"]*)"') do
			if #str > 0 then
				table.insert(strings, str)
			end
		end
		
		for str in array_content:gmatch("'([^']*)'") do
			if #str > 0 and not table.concat(strings):find(str) then
				table.insert(strings, str)
			end
		end
	end
	
	return strings
end

function WeareDevsLayer.extract_all_bytecode_data(code)
	local data = {}
	
	for str in code:gmatch('"([%w%+/%=]{40,})"') do
		table.insert(data, str)
	end
	
	for str in code:gmatch("'([%w%+/%=]{40,})'") do
		table.insert(data, str)
	end
	
	return data
end

function WeareDevsLayer.analyze_bytecode(bytecode_bytes)
	if not bytecode_bytes or #bytecode_bytes < 4 then
		return nil
	end
	
	local magic = bytecode_bytes:sub(1, 1)
	
	if magic == string.char(0x23) then
		return { format = "LuaJIT 2.0+", magic = "0x23", version = 2 }
	elseif magic == string.char(0x1b) then
		return { format = "Lua 5.1", magic = "0x1b", version = 5 }
	elseif magic == string.char(0x1f) then
		return { format = "Lua 5.2", magic = "0x1f", version = 52 }
	elseif magic == string.char(0x24) then
		return { format = "Lua 5.3", magic = "0x24", version = 53 }
	end
	
	return { format = "unknown", magic = magic:byte() }
end

function WeareDevsLayer.decode_bytecode_chunks(code)
	local chunks = {}
	local arrays = WeareDevsLayer.find_all_arrays(code)
	
	for _, array_name in ipairs(arrays) do
		local strings = WeareDevsLayer.extract_base64_strings(code, array_name)
		
		for i, b64 in ipairs(strings) do
			if b64 and #b64 > 0 then
				local decoded = Base64.decode(b64)
				if decoded and #decoded > 0 then
					table.insert(chunks, {
						array = array_name,
						index = i,
						encoded_len = #b64,
						decoded_len = #decoded,
						analysis = WeareDevsLayer.analyze_bytecode(decoded),
						data = decoded
					})
				end
			end
		end
	end
	
	return chunks
end

function WeareDevsLayer.detect_encryption_pattern(code)
	if code:match("XOR") then return "xor" end
	if code:match("bit%.bxor") then return "bitwise_xor" end
	if code:match("bit%.band") then return "bitwise_and" end
	if code:match("bit%.bor") then return "bitwise_or" end
	if code:match("bit%.bnot") then return "bitwise_not" end
	return nil
end

function WeareDevsLayer.apply_xor_decryption(data, key)
	if not key or key == 0 then return data end
	
	local result = {}
	for i = 1, #data do
		local byte = data:sub(i, i):byte()
		local decrypted = bit32.bxor(byte, key)
		table.insert(result, string.char(decrypted))
	end
	
	return table.concat(result)
end

function WeareDevsLayer.extract_function_bodies(code)
	local bodies = {}
	
	for body in code:gmatch("function%s*%([^)]*%)%s*(.-)%s*end") do
		table.insert(bodies, body)
	end
	
	for body in code:gmatch("local%s+%w+%s*=%s*function%s*%([^)]*%)%s*(.-)%s*end") do
		table.insert(bodies, body)
	end
	
	return bodies
end

function WeareDevsLayer.deobfuscate(code)
	if not WeareDevsLayer.detect(code) then
		return code, 0
	end
	
	local unwrapped = code
	unwrapped = unwrapped:gsub('^%s*return%s*%(%s*', '')
	unwrapped = unwrapped:gsub('%)%s*%(%s*%.%.%.%s*%)%s*[;$]', '')
	
	local arrays = WeareDevsLayer.find_all_arrays(unwrapped)
	local chunks = WeareDevsLayer.decode_bytecode_chunks(unwrapped)
	
	local result = "-- WEAREDEVS OBFUSCATED CODE (BYTECODE-BASED DEOBFUSCATION)\n"
	result = result .. "-- total_arrays: " .. #arrays .. "\n"
	result = result .. "-- total_bytecode_chunks: " .. #chunks .. "\n"
	result = result .. "-- encryption_pattern: " .. (WeareDevsLayer.detect_encryption_pattern(unwrapped) or "none") .. "\n"
	
	local xor_keys = WeareDevsLayer.detect_xor_key(unwrapped)
	if #xor_keys > 0 then
		result = result .. "-- detected_xor_keys: " .. table.concat(xor_keys, ", ") .. "\n"
	end
	
	result = result .. "\n"
	
	if #chunks > 0 then
		result = result .. "-- Bytecode Analysis:\n"
		for i, chunk in ipairs(chunks) do
			if chunk.analysis then
				result = result .. "--   chunk " .. i .. " (" .. chunk.array .. "[" .. chunk.index .. "]): "
				result = result .. chunk.analysis.format .. " (" .. chunk.decoded_len .. " bytes)\n"
			end
		end
		result = result .. "\n-- BYTECODE EXTRACTION COMPLETE\n"
		result = result .. "-- Use LuaJIT decompiler (unluac, ljd, etc) for full source recovery\n\n"
	end
	
	result = result .. "-- Original wrapped code:\n"
	result = result .. unwrapped
	
	return result, #chunks
end

function WeareDevsLayer.export_bytecode(code, output_dir)
	if not WeareDevsLayer.detect(code) then
		return false, 0
	end
	
	local chunks = WeareDevsLayer.decode_bytecode_chunks(code)
	
	local exported = 0
	for i, chunk in ipairs(chunks) do
		local filename = (output_dir or "/tmp") .. "/wearedevs_bytecode_" .. i .. ".luac"
		local f = io.open(filename, "wb")
		if f then
			f:write(chunk.data)
			f:close()
			exported = exported + 1
		end
	end
	
	return exported > 0, exported
end

function WeareDevsLayer.create_decompiler_hints(code)
	local hints = {
		chunks = WeareDevsLayer.decode_bytecode_chunks(code),
		encryption = WeareDevsLayer.detect_encryption_pattern(code),
		xor_keys = WeareDevsLayer.detect_xor_key(code),
		functions = WeareDevsLayer.extract_function_bodies(code)
	}
	return hints
end

function WeareDevsLayer.analyze_structure(code)
	local structure = {
		arrays_count = #WeareDevsLayer.find_all_arrays(code),
		bytecode_chunks = #WeareDevsLayer.decode_bytecode_chunks(code),
		functions_count = #WeareDevsLayer.extract_function_bodies(code),
		has_xor = WeareDevsLayer.detect_xor_key(code) and true or false,
		encryption_type = WeareDevsLayer.detect_encryption_pattern(code)
	}
	return structure
end

return WeareDevsLayer
