local AntiTamper = {}

function AntiTamper.detect(code)
	if code:match("debug%.traceback") then
		return true
	end
	if code:match("getfenv") and code:match("debug") then
		return true
	end
	if code:match("setmetatable.*__index") and code:match("error") then
		return true
	end
	return false
end

function AntiTamper.find_checks(code)
	local checks = {}
	
	for check in string.gmatch(code, "if%s+[^t]+then%s*error") do
		table.insert(checks, check)
	end
	
	for check in string.gmatch(code, "local%s+%w+%s*=%s*getfenv") do
		table.insert(checks, check)
	end
	
	return checks
end

function AntiTamper.remove_checks(code)
	local result = code
	
	result = result:gsub("if%s+debug%.traceback%s+then%s*error%([^)]+%)%s*end", "")
	result = result:gsub("if%s+getfenv%(%)%s*then%s*error%([^)]+%)%s*end", "")
	result = result:gsub("local%s+%w+%s*=%s*getfenv%(%)[^%w]*", "")
	
	result = result:gsub("\n%s*\n%s*\n", "\n\n")
	
	return result
end

function AntiTamper.remove_watermark(code)
	local result = code
	
	result = result:gsub("__prometheus[%w_]*", "")
	result = result:gsub("Prometheus%-Alpha%-[%w%.]+", "")
	result = result:gsub('local%s+%w*prometheus%w*%s*=%s*"[^"]*"', "")
	
	return result
end

function AntiTamper.reverse_all(code)
	local result = AntiTamper.remove_checks(code)
	result = AntiTamper.remove_watermark(result)
	return result
end

return AntiTamper
