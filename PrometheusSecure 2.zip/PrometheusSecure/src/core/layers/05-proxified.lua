local ProxifyLocals = {}

function ProxifyLocals.find_proxified_locals(code)
	local proxified = {}
	
	for var_name in string.gmatch(code, "local%s+(%w+)%s*=%s*setmetatable%s*%s*%(%s*%{") do
		table.insert(proxified, var_name)
	end
	
	for var_name in string.gmatch(code, "local%s+(%w+)%s*=%s*setmetatable%s*%(%s*%{[^}]*%}%s*,%s*%{[^}]*__index") do
		if not table.concat(proxified):find(var_name) then
			table.insert(proxified, var_name)
		end
	end
	
	for var_name in string.gmatch(code, "local%s+(%w+)%s*=%s*setmetatable%s*%(%s*%{[^}]*%}%s*,%s*%{[^}]*__newindex") do
		if not table.concat(proxified):find(var_name) then
			table.insert(proxified, var_name)
		end
	end
	
	return proxified
end

function ProxifyLocals.find_value_key(code, proxy_var)
	local pattern = proxy_var .. "%s*=%s*setmetatable%s*%(%s*%{([^}]*)"
	local content = code:match(pattern)
	
	if content then
		for key in string.gmatch(content, "(%w+)%s*=") do
			if key ~= "val" and key ~= "value" and key ~= "v" then
				break
			end
			return key
		end
	end
	
	return "value"
end

function ProxifyLocals.detect_metatable_patterns(code)
	local patterns = {
		index = (code:match("__index%s*=%s*function") and 1 or 0),
		newindex = (code:match("__newindex%s*=%s*function") and 1 or 0),
		call = (code:match("__call%s*=%s*function") and 1 or 0),
		add = (code:match("__add%s*=%s*function") and 1 or 0),
		sub = (code:match("__sub%s*=%s*function") and 1 or 0),
		mul = (code:match("__mul%s*=%s*function") and 1 or 0),
		div = (code:match("__div%s*=%s*function") and 1 or 0),
		eq = (code:match("__eq%s*=%s*function") and 1 or 0),
		lt = (code:match("__lt%s*=%s*function") and 1 or 0),
		le = (code:match("__le%s*=%s*function") and 1 or 0)
	}
	return patterns
end

function ProxifyLocals.analyze_proxy_usage(code, proxy_var)
	local usage = {
		total_refs = 0,
		operations = {}
	}
	
	for _ in string.gmatch(code, proxy_var .. "%s*%-[^-]%s*0") do
		usage.operations.subtract = (usage.operations.subtract or 0) + 1
	end
	
	for _ in string.gmatch(code, proxy_var .. "%s*%+%s*0") do
		usage.operations.add = (usage.operations.add or 0) + 1
	end
	
	for _ in string.gmatch(code, proxy_var .. "%s*%*%s*1") do
		usage.operations.multiply = (usage.operations.multiply or 0) + 1
	end
	
	for _ in string.gmatch(code, proxy_var .. "%s*/%s*1") do
		usage.operations.divide = (usage.operations.divide or 0) + 1
	end
	
	for _ in string.gmatch(code, proxy_var .. "%[") do
		usage.total_refs = usage.total_refs + 1
	end
	
	return usage
end

function ProxifyLocals.reverse_metamethod_ops(code, proxy_var)
	code = code:gsub(proxy_var .. "%s*%-[^-]%s*0", proxy_var)
	code = code:gsub(proxy_var .. "%s*%+[%s]*0", proxy_var)
	code = code:gsub(proxy_var .. "%s*%*[%s]*1", proxy_var)
	code = code:gsub(proxy_var .. "%s*/[%s]*1", proxy_var)
	code = code:gsub(proxy_var .. "%s*%%[%s]*1", proxy_var)
	code = code:gsub(proxy_var .. "%[%s*['\"]val['\"]%s*%]", proxy_var)
	code = code:gsub(proxy_var .. "%[%s*['\"]value['\"]%s*%]", proxy_var)
	code = code:gsub(proxy_var .. "%[%s*['\"]v['\"]%s*%]", proxy_var)
	code = code:gsub(proxy_var .. "%[%s*['\"]data['\"]%s*%]", proxy_var)
	
	return code
end

function ProxifyLocals.extract_metatable_references(code)
	local refs = {}
	
	for ref in string.gmatch(code, "getmetatable%s*%(%s*(%w+)%s*%)") do
		table.insert(refs, ref)
	end
	
	for ref in string.gmatch(code, "setmetatable%s*%(%s*(%w+)") do
		table.insert(refs, ref)
	end
	
	return refs
end

function ProxifyLocals.remove_setmetatable_wrappers(code)
	local result = code
	
	result = result:gsub(
		"local%s+%w+%s*=%s*setmetatable%s*%(%s*%{[^}]*%}%s*,%s*%{[^}]*%}%s*%)",
		""
	)
	
	result = result:gsub(
		"setmetatable%s*%(%s*%w+%s*,%s*%{[^}]*%}%s*%)",
		""
	)
	
	result = result:gsub("%s*\n%s*\n%s*\n", "\n\n")
	
	return result
end

function ProxifyLocals.reverse_all(code)
	local proxified = ProxifyLocals.find_proxified_locals(code)
	
	for _, var_name in ipairs(proxified) do
		code = ProxifyLocals.reverse_metamethod_ops(code, var_name)
	end
	
	code = ProxifyLocals.remove_setmetatable_wrappers(code)
	
	return code
end

return ProxifyLocals
