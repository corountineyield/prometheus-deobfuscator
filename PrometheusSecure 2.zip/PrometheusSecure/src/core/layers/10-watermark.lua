local Watermark = {}

function Watermark.detect(code)
	if code:match("__prometheus") then
		return true
	end
	if code:match("Prometheus%-Alpha") then
		return true
	end
	if code:match("Watermark") then
		return true
	end
	return false
end

function Watermark.find_watermark(code)
	local marks = {}
	
	for mark in string.gmatch(code, "__prometheus[%w_]*") do
		table.insert(marks, mark)
	end
	
	for mark in string.gmatch(code, "Prometheus%-Alpha%-[%w%.]+") do
		table.insert(marks, mark)
	end
	
	for mark in string.gmatch(code, "local%s+%w*prometheus%w*%s*=%s*\"[^\"]*\"") do
		table.insert(marks, mark)
	end
	
	return marks
end

function Watermark.remove_prometheus_marker(code)
	local result = code
	result = result:gsub("__prometheus[%w_]*", "")
	result = result:gsub("Prometheus%-Alpha%-[%w%.]+", "")
	result = result:gsub('local%s+%w*prometheus%w*%s*=%s*"[^"]*"', "")
	return result
end

function Watermark.remove_custom_watermark(code)
	local result = code
	result = result:gsub("%-%-[%s]*Watermark:[%s]*[^\n]*", "")
	result = result:gsub("local%s+%w*mark%w*%s*=%s*\"[^\"]*\"", "")
	return result
end

function Watermark.remove_all(code)
	local result = Watermark.remove_prometheus_marker(code)
	result = Watermark.remove_custom_watermark(result)
	result = result:gsub("\n%s*\n%s*\n", "\n\n")
	return result
end

return Watermark
