local Vmify = {}

function Vmify.is_vmified(code)
        if code:match("local%s+%w+%s*=%s*%{%s*%d+%s*,") then
                return true
        end
        if code:match("while%s+true%s+do") and code:match("if%s+.*%s+then") then
                return true
        end
        if code:match("repeat") or code:match("::") then
                return true
        end
        if code:match("function%s+%w+%s*%(.*%)%s*local%s+%w+%s*=%s*%{.*%d.*%}") then
                return true
        end
        return false
end

function Vmify.extract_bytecode_arrays(code)
        local arrays = {}
        for var_name, content in string.gmatch(code, "local%s+(%w+)%s*=%s*%{%s*([%d%s,]+)%s*%}") do
                local bytecode = {}
                local byte_count = 0
                for byte_str in string.gmatch(content, "%d+") do
                        local b = tonumber(byte_str)
                        if b >= 0 and b <= 255 then
                                table.insert(bytecode, b)
                                byte_count = byte_count + 1
                        end
                end
                if byte_count > 20 then
                        table.insert(arrays, {
                                name = var_name,
                                data = bytecode,
                                size = byte_count
                        })
                end
        end
        return arrays
end

function Vmify.find_dispatcher(code)
        local pattern = "while%s+true%s+do[^e]*end"
        local matches = {}
        for match in string.gmatch(code, pattern) do
                table.insert(matches, match)
        end
        return matches
end

function Vmify.find_state_machine(code)
        local state_vars = {}
        for var in string.gmatch(code, "local%s+(%w+)%s*=%s*0%s*") do
                table.insert(state_vars, var)
        end
        return state_vars
end

function Vmify.extract_constants(bytecode)
        if not bytecode or #bytecode < 4 then
                return {}
        end
        local constants = {
                strings = {},
                numbers = {},
                raw = {}
        }
        
        local current_str = ""
        for i = 1, #bytecode do
                local byte = bytecode[i]
                if byte >= 32 and byte <= 126 then
                        current_str = current_str .. string.char(byte)
                else
                        if #current_str > 2 then
                                table.insert(constants.strings, current_str)
                        end
                        current_str = ""
                end
        end
        if #current_str > 2 then
                table.insert(constants.strings, current_str)
        end
        
        for i = 1, #bytecode - 3 do
                local num = bytecode[i] * 256^3 + bytecode[i+1] * 256^2 + bytecode[i+2] * 256 + bytecode[i+3]
                if num > 0 and num < 10000000 then
                        table.insert(constants.numbers, num)
                end
        end
        
        return constants
end

function Vmify.analyze_bytecode_structure(bytecode)
        if not bytecode or #bytecode == 0 then
                return {}
        end
        local analysis = {
                total_size = #bytecode,
                instruction_estimate = math.floor(#bytecode / 4),
                opcodes = {},
                patterns = {},
                magic_bytes = {}
        }
        
        local opcode_freq = {}
        for i = 1, math.min(#bytecode, 1000), 4 do
                local opcode = bytecode[i]
                opcode_freq[opcode] = (opcode_freq[opcode] or 0) + 1
        end
        
        analysis.opcodes = opcode_freq
        
        if #bytecode >= 3 then
                analysis.magic_bytes = {bytecode[1], bytecode[2], bytecode[3]}
        end
        
        return analysis
end

function Vmify.detect_bytecode_format(bytecode)
        if not bytecode or #bytecode < 1 then
                return nil
        end
        
        local first_byte = bytecode[1]
        if first_byte == 0x23 then
                return "LuaJIT"
        elseif first_byte == 0x1b then
                return "Lua 5.1"
        elseif first_byte == 0x1f then
                return "Lua 5.2"
        elseif first_byte == 0x24 then
                return "Lua 5.3"
        end
        
        return "Unknown"
end

function Vmify.export_bytecode(bytecode, output_path)
        if not bytecode or #bytecode == 0 then
                return false, "empty bytecode"
        end
        local header = string.char(0x23)
        header = header .. string.char(2)
        header = header .. string.char(1)
        local proto = ""
        for i = 1, #bytecode do
                proto = proto .. string.char(bytecode[i])
        end
        local full_bytecode = header .. proto
        if output_path then
                local f = io.open(output_path, "wb")
                if f then
                        f:write(full_bytecode)
                        f:close()
                        return true, output_path
                end
        end
        return false, "could not write file"
end

function Vmify.analyze(code)
        if not Vmify.is_vmified(code) then
                return nil
        end
        local arrays = Vmify.extract_bytecode_arrays(code)
        local analysis = {
                is_vmified = true,
                bytecode_arrays = #arrays,
                state_machines = #Vmify.find_state_machine(code),
                dispatchers = #Vmify.find_dispatcher(code),
                details = {}
        }
        for idx, arr in ipairs(arrays) do
                local constants = Vmify.extract_constants(arr.data)
                local struct = Vmify.analyze_bytecode_structure(arr.data)
                table.insert(analysis.details, {
                        array_name = arr.name,
                        size = arr.size,
                        format = Vmify.detect_bytecode_format(arr.data),
                        constants = constants,
                        structure = struct
                })
        end
        return analysis
end

function Vmify.devirtualize(code)
        if not Vmify.is_vmified(code) then
                return code, false
        end
        local arrays = Vmify.extract_bytecode_arrays(code)
        if #arrays == 0 then
                return code, false
        end
        
        -- BUG FIX: Don't extract inner content, just remove the bytecode arrays
        -- The bytecode arrays are noise - removing them simplifies the code
        -- but the dispatcher structure should be preserved as-is
        
        local simplified = code
        
        -- Remove bytecode array declarations (the large numeric tables)
        -- Pattern: local VAR = { numbers, numbers, numbers ... }
        simplified = simplified:gsub('local%s+%w+%s*=%s*%{[%d%s,\n]+%}', '')
        
        -- Clean up any resulting empty lines or excessive whitespace
        simplified = simplified:gsub('\n%s*\n%s*\n', '\n\n')
        
        return simplified, true
end

function Vmify.export_analysis(code, output_path)
        local analysis = Vmify.analyze(code)
        if not analysis then
                return false
        end
        local devirtualized = Vmify.devirtualize(code)
        if output_path then
                local f = io.open(output_path, "w")
                if f then
                        f:write(devirtualized)
                        f:close()
                        return true
                end
        end
        return false
end

return Vmify
