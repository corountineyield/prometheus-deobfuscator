local Base64 = require("src.core.utils.base64")

local ConstantArray = {}

function ConstantArray.find_all_arrays(code)
	local arrays = {}
	
	for array_name, array_content in string.gmatch(code, "local%s+(%w+)%s*=%s*%{([^}]-)%}") do
		if #array_content > 30 then
			table.insert(arrays, {
				name = array_name,
				content = array_content
			})
		end
	end
	
	return arrays
end

function ConstantArray.find_constant_array(code)
	local arrays = ConstantArray.find_all_arrays(code)
	return arrays[1] and arrays[1].name, arrays[1] and arrays[1].content
end

function ConstantArray.extract_array_elements(array_content)
	local elements = {}
	
	for element in string.gmatch(array_content, '"([^"]*)"') do
		table.insert(elements, element)
	end
	
	for element in string.gmatch(array_content, "'([^']*)'") do
		table.insert(elements, element)
	end
	
	for element in string.gmatch(array_content, "(%d+)") do
		table.insert(elements, element)
	end
	
	return elements
end

function ConstantArray.find_base64_lookup(code)
	local lookups = {}
	
	for lookup in string.gmatch(code, "([A-Za-z0-9%+/%=]{60,})") do
		if #lookup >= 60 then
			table.insert(lookups, lookup)
		end
	end
	
	local custom = code:match('local%s+%w+%s*=%s*"([ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0-9%+/%=]+)"')
	if custom then
		return custom
	end
	
	return lookups[1]
end

function ConstantArray.find_wrapper_offset(code)
	for offset_str in string.gmatch(code, "%-(%d+)%s*%]") do
		local offset = tonumber(offset_str)
		if offset and offset > 0 then
			return offset
		end
	end
	
	return 0
end

function ConstantArray.decode_elements(elements, alphabet)
	local decoded = {}
	
	for _, element in ipairs(elements) do
		local decoded_element = nil
		
		if alphabet and #alphabet > 0 then
			decoded_element = Base64.decode(element, alphabet)
		end
		
		if not decoded_element or #(decoded_element or "") == 0 then
			decoded_element = Base64.decode(element)
		end
		
		if decoded_element then
			table.insert(decoded, decoded_element)
		else
			table.insert(decoded, element)
		end
	end
	
	return decoded
end

function ConstantArray.inline_constants(code, array_name, decoded_elements, offset)
	offset = offset or 0
	
	if not array_name or not decoded_elements or #decoded_elements == 0 then
		return code
	end
	
	local function escape_string(s)
		return s:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "\\r")
	end
	
	local function replace_index(index_str)
		local index = tonumber(index_str)
		if index and decoded_elements[index - offset] then
			local decoded = decoded_elements[index - offset]
			if type(decoded) == "string" then
				return '"' .. escape_string(decoded) .. '"'
			end
		end
		return index_str
	end
	
	code = code:gsub(array_name .. "%[%s*(%d+)%s*%]", replace_index)
	code = code:gsub("wrapper%(%s*(%d+)%s*%)", replace_index)
	code = code:gsub(array_name .. "%[%s*(%d+)%s*%-[%d]+%s*%]", replace_index)
	code = code:gsub("local%s+" .. array_name .. "%s*=%s*%{[^}]*%}", "")
	
	return code
end

function ConstantArray.process(code)
	local arrays = ConstantArray.find_all_arrays(code)
	
	if #arrays == 0 then
		return code, 0
	end
	
	local processed = code
	local count = 0
	
	for _, arr in ipairs(arrays) do
		local elements = ConstantArray.extract_array_elements(arr.content)
		local alphabet = ConstantArray.find_base64_lookup(processed)
		local offset = ConstantArray.find_wrapper_offset(processed)
		
		if #elements > 0 then
			local decoded = ConstantArray.decode_elements(elements, alphabet)
			processed = ConstantArray.inline_constants(processed, arr.name, decoded, offset)
			count = count + 1
		end
	end
	
	return processed, count
end

function ConstantArray.analyze_array_statistics(arrays)
	local stats = {
		total_arrays = #arrays,
		total_elements = 0,
		avg_element_size = 0,
		array_sizes = {}
	}
	
	for _, arr in ipairs(arrays) do
		local elements = ConstantArray.extract_array_elements(arr.content)
		stats.total_elements = stats.total_elements + #elements
		table.insert(stats.array_sizes, #elements)
	end
	
	if stats.total_arrays > 0 then
		stats.avg_element_size = math.floor(stats.total_elements / stats.total_arrays)
	end
	
	return stats
end

return ConstantArray
