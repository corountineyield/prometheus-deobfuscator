local NumberExpressions = {}

function NumberExpressions.detect(code)
	if code:match("%(%d+%s*[+%-*/%^]%s*%d+%)") then
		return true
	end
	if code:match("%-%-[%d]+") then
		return true
	end
	return false
end

function NumberExpressions.simplify_expressions(code)
	local result = code
	local iterations = 0
	local max_iterations = 100
	
	while iterations < max_iterations do
		local changed = false
		
		result = result:gsub("%((%d+)%s*%+%s*(%d+)%)", function(a, b)
			changed = true
			return tostring(tonumber(a) + tonumber(b))
		end)
		
		result = result:gsub("%((%d+)%s*%-%s*(%d+)%)", function(a, b)
			changed = true
			return tostring(tonumber(a) - tonumber(b))
		end)
		
		result = result:gsub("%((%d+)%s*%*%s*(%d+)%)", function(a, b)
			changed = true
			return tostring(tonumber(a) * tonumber(b))
		end)
		
		result = result:gsub("%((%d+)%s*/%s*(%d+)%)", function(a, b)
			local divisor = tonumber(b)
			if divisor ~= 0 then
				changed = true
				return tostring(math.floor(tonumber(a) / divisor))
			end
			return "(" .. a .. "/" .. b .. ")"
		end)
		
		if not changed then
			break
		end
		iterations = iterations + 1
	end
	
	return result
end

function NumberExpressions.reverse_all(code)
	return NumberExpressions.simplify_expressions(code)
end

return NumberExpressions
