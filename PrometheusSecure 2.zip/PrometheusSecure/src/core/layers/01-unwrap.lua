local Unwrap = {}

function Unwrap.detect_wrapper(code)
	if code:match("return%s*%(%s*function%s*%(%.%.%.%)") then
		return true
	end
	if code:match("return%s*%(%s*function%s*%(%s*%)%s*") then
		return true
	end
	if code:match("^%s*%(%s*function%s*%(%.%.%.%)") then
		return true
	end
	if code:match("do%s+local%s+%w+%s*=%s*function") then
		return true
	end
	if code:match("local%s+%w+%s*=%s*function%s*%(%s*%.%.%.%s*%)%s*return") then
		return true
	end
	return false
end

function Unwrap.unwrap_once(code)
	local pattern1 = "return%s*%(%s*function%s*%(%s*%.%.%.%s*%)%s*(.-)%s*end%s*%)%s*%(%s*%.%.%.%s*%)"
	local inner = code:match(pattern1)
	if inner then return inner, true end
	
	local pattern2 = "return%s*%(%s*function%s*%(%s*%)%s*(.-)%s*end%s*%)%s*%(%s*%)"
	inner = code:match(pattern2)
	if inner then return inner, true end
	
	local pattern3 = "^%s*%(%s*function%s*%(%s*%.%.%.%s*%)%s*(.-)%s*end%s*%)%s*%(%s*%.%.%.%s*%)%s*$"
	inner = code:match(pattern3)
	if inner then return inner, true end
	
	local pattern4 = "return%s*%(%s*function%s*%(%s*%w+%s*%)%s*(.-)%s*end%s*%)%s*%(%s*%w+%s*%)"
	inner = code:match(pattern4)
	if inner then return inner, true end
	
	local pattern5 = "do%s+local%s+%w+%s*=%s*function%s*%(%s*%.%.%.%s*%)%s*(.-)%s*end%s+return%s+%w+%s*end"
	inner = code:match(pattern5)
	if inner then return inner, true end
	
	local pattern6 = "local%s+%w+%s*=%s*function%s*%(%s*%.%.%.%s*%)%s*(.-)%s*end%s*return%s*%w+"
	inner = code:match(pattern6)
	if inner then return inner, true end
	
	local pattern7 = "local%s+%w+%s*=%s*function%s*%(%s*%w+%s*%)%s*(.-)%s*end%s*return%s+%w+%s*%(%s*%w+%s*%)"
	inner = code:match(pattern7)
	if inner then return inner, true end
	
	local pattern8 = "%(%s*function%s*%(%s*%.%.%.%s*%)%s*(.-)%s*end%s*%)%s*%(%s*%.%.%.%s*%)"
	inner = code:match(pattern8)
	if inner then return inner, true end
	
	return code, false
end

function Unwrap.count_wrappers(code)
	local count = 0
	if code:match("return%s*%(%s*function") then count = count + 1 end
	if code:match("^%s*%(%s*function") then count = count + 1 end
	if code:match("do%s+local%s+%w+%s*=%s*function") then count = count + 1 end
	if code:match("local%s+%w+%s*=%s*function.*return%s+%w+") then count = count + 1 end
	return count
end

function Unwrap.unwrap_all(code)
	local unwrapped = code
	local iterations = 0
	local max_iterations = 150
	local prev_len = #unwrapped
	
	while Unwrap.detect_wrapper(unwrapped) and iterations < max_iterations do
		local new_code, was_unwrapped = Unwrap.unwrap_once(unwrapped)
		
		if not was_unwrapped or #new_code == #unwrapped then
			break
		end
		
		unwrapped = new_code
		iterations = iterations + 1
		
		if #unwrapped > prev_len * 2 then
			break
		end
		prev_len = #unwrapped
	end
	
	return unwrapped, iterations
end

function Unwrap.find_wrapper_entry_point(code)
	local entry_points = {}
	
	for name in string.gmatch(code, "local%s+(%w+)%s*=%s*function%s*%(%s*%.%.%.%s*%)%s*(.-)%s*end") do
		table.insert(entry_points, name)
	end
	
	for name in string.gmatch(code, "return%s*%(%s*function%s*%(%s*%.%.%.%s*%)%s*(.-)%s*end%s*%)") do
		table.insert(entry_points, "anonymous_return")
	end
	
	return entry_points
end

function Unwrap.analyze_wrapper_depth(code)
	local depth = 0
	local current = code
	
	while Unwrap.detect_wrapper(current) and depth < 100 do
		local next, unwrapped = Unwrap.unwrap_once(current)
		if not unwrapped then break end
		current = next
		depth = depth + 1
	end
	
	return depth
end

return Unwrap
