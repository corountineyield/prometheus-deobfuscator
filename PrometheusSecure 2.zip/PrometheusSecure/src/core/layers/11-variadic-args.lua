local VariadicArgs = {}

function VariadicArgs.detect(code)
	if code:match("function%s+%w+%s*%(%.%.%.%)") then
		return true
	end
	if code:match("local%s+function%s*%(%.%.%.%)") then
		return true
	end
	if code:match("%.%.%.%s*%)%s*end") then
		return true
	end
	return false
end

function VariadicArgs.find_variadic_functions(code)
	local functions = {}
	
	for name in string.gmatch(code, "function%s+(%w+)%s*%(%.%.%.%)") do
		table.insert(functions, name)
	end
	
	for func_def in string.gmatch(code, "function%s+%w+%s*%(%.%.%.%)%s*[^e]*end") do
		table.insert(functions, func_def)
	end
	
	return functions
end

function VariadicArgs.analyze_variadic_usage(code)
	local analysis = {
		total_functions = 0,
		variadic_only = 0,
		has_other_params = 0,
		uses_args = 0
	}
	
	for _ in string.gmatch(code, "function%s+%w+%s*%(") do
		analysis.total_functions = analysis.total_functions + 1
	end
	
	for _ in string.gmatch(code, "function%s+%w+%s*%(%.%.%.%)") do
		analysis.variadic_only = analysis.variadic_only + 1
	end
	
	for _ in string.gmatch(code, "local%s+%w+%s*%=%s*%.%.%.") do
		analysis.uses_args = analysis.uses_args + 1
	end
	
	return analysis
end

function VariadicArgs.mark_functions_using_args(code)
	local marked = code
	
	marked = marked:gsub("(function%s+%w+%s*%(%.%.%.%)%s*)", function(func_sig)
		if func_sig:match("%.%.%.") then
			return func_sig
		end
		return func_sig
	end)
	
	return marked
end

function VariadicArgs.is_unused_variadic(code, function_name)
	local pattern = "function%s+" .. function_name .. "%s*%(%.%.%.%)%s*([^e]*)"
	local body = code:match(pattern)
	
	if not body then
		return false
	end
	
	if not body:match("%.%.%.") and not body:match("arg") then
		return true
	end
	
	return false
end

function VariadicArgs.analyze_all(code)
	return VariadicArgs.analyze_variadic_usage(code)
end

return VariadicArgs
