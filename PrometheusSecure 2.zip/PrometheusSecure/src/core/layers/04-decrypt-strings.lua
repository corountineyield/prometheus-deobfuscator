local PRNG = require("src.core.prng.algorithm")
local SeedFinder = require("src.core.prng.seed-finder")

local DecryptStrings = {}

function DecryptStrings.find_encrypted_strings(code)
	local encrypted = {}
	local seen = {}
	
	for encrypted_str, seed_str in string.gmatch(code, 'DECRYPT%s*%(["\']([^"\']*)["\'],%s*(%d+)%s*%)') do
		local seed = tonumber(seed_str)
		if seed and not seen[seed] then
			seen[seed] = true
			table.insert(encrypted, {
				encrypted = encrypted_str,
				seed = seed
			})
		end
	end
	
	for encrypted_str, seed_str in string.gmatch(code, '["\']([%w%+/%=]+)["\']%s*,%s*(%d+)') do
		local seed = tonumber(seed_str)
		if seed and not seen[seed] and #encrypted_str > 10 then
			seen[seed] = true
			table.insert(encrypted, {
				encrypted = encrypted_str,
				seed = seed
			})
		end
	end
	
	return encrypted
end

function DecryptStrings.extract_keys_from_code(code)
	local keys = {}
	
	for num_str in string.gmatch(code, "%b()") do
		local nums = {}
		for n in string.gmatch(num_str, "(%d+)") do
			table.insert(nums, tonumber(n))
		end
		if #nums >= 4 then
			table.insert(keys, nums)
		end
	end
	
	for secret_key_6, secret_key_7, secret_key_44, secret_key_8 in 
		string.gmatch(code, "secret%s*:%s*%{%s*(%d+)%s*,%s*(%d+)%s*,%s*(%d+)%s*,%s*(%d+)%s*%}") do
		table.insert(keys, {tonumber(secret_key_6), tonumber(secret_key_7), tonumber(secret_key_44), tonumber(secret_key_8)})
	end
	
	return keys
end

function DecryptStrings.find_prng_constants(code)
	local constants = {}
	
	for const in string.gmatch(code, "local%s+%w+%s*=%s*(%d+)") do
		table.insert(constants, tonumber(const))
	end
	
	return constants
end

function DecryptStrings.detect_encryption_type(encrypted_string)
	if encrypted_string:match("[%w%+/%=]+") then
		return "base64"
	end
	if encrypted_string:match("%x%x%x%x") then
		return "hex"
	end
	return "unknown"
end

function DecryptStrings.find_keys_by_brute_force(encrypted_strings, code)
	if not encrypted_strings or #encrypted_strings == 0 then
		return {}
	end
	
	local results = {}
	
	local test_combinations = {
		{6, 88, 1234567890, 198},
		{42, 100, 9876543210, 200},
		{50, 127, 17592186044415, 255},
		{1, 1, 1, 1},
		{0, 0, 0, 0},
		{123, 456, 789123, 999},
		{111, 222, 333444, 555}
	}
	
	local extracted = DecryptStrings.extract_keys_from_code(code)
	for _, keys in ipairs(extracted) do
		if #keys >= 4 then
			table.insert(test_combinations, keys)
		end
	end
	
	for _, combo in ipairs(test_combinations) do
		local key6, key7, key44, key8 = unpack(combo)
		
		local total_confidence = 0
		local successful_decrypts = 0
		
		for _, item in ipairs(encrypted_strings) do
			local result = SeedFinder.test_seed(
				item.encrypted,
				item.seed,
				key6, key7, key44, key8
			)
			
			if result then
				total_confidence = total_confidence + (result.confidence or 0)
				if result.confidence and result.confidence > 0 then
					successful_decrypts = successful_decrypts + 1
				end
			end
		end
		
		if successful_decrypts > 0 then
			table.insert(results, {
				keys = combo,
				confidence = total_confidence / #encrypted_strings,
				successful = successful_decrypts,
				key6 = key6,
				key7 = key7,
				key44 = key44,
				key8 = key8
			})
		end
	end
	
	table.sort(results, function(a, b) 
		return a.confidence > b.confidence 
	end)
	
	return results
end

function DecryptStrings.decrypt_all(code, secret_key_6, secret_key_7, secret_key_44, secret_key_8)
	if not secret_key_6 or not secret_key_7 or not secret_key_44 or not secret_key_8 then
		return code, 0
	end
	
	local encrypted = DecryptStrings.find_encrypted_strings(code)
	if #encrypted == 0 then
		return code, 0
	end
	
	local decryptor = PRNG.create_decryptor(secret_key_6, secret_key_7, secret_key_44, secret_key_8)
	local count = 0
	
	for _, item in ipairs(encrypted) do
		local decrypted = decryptor.decrypt(item.encrypted, item.seed)
		
		if decrypted and decrypted ~= item.encrypted then
			local escaped = decrypted:gsub("\\", "\\\\"):gsub('"', '\\"')
			local escaped_enc = item.encrypted:gsub("[%^%$%(%)%.%[%]%*%+%-%?]", "%%%1")
			local pattern = 'DECRYPT%s*%(["\']' .. escaped_enc .. '["\'],%s*' .. item.seed .. '%s*%)'
			code = code:gsub(pattern, '"' .. escaped .. '"')
			count = count + 1
		end
	end
	
	return code, count
end

function DecryptStrings.analyze_encryption_stats(encrypted_strings)
	local stats = {
		total = #encrypted_strings,
		by_type = {},
		by_seed = {},
		avg_length = 0,
		total_encrypted_size = 0
	}
	
	for _, item in ipairs(encrypted_strings) do
		local enc_type = DecryptStrings.detect_encryption_type(item.encrypted)
		stats.by_type[enc_type] = (stats.by_type[enc_type] or 0) + 1
		stats.by_seed[item.seed] = (stats.by_seed[item.seed] or 0) + 1
		stats.total_encrypted_size = stats.total_encrypted_size + #item.encrypted
	end
	
	if stats.total > 0 then
		stats.avg_length = math.floor(stats.total_encrypted_size / stats.total)
	end
	
	return stats
end

return DecryptStrings
