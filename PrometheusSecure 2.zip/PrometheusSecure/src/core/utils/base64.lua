local Base64 = {}

function Base64.decode(data, alphabet)
	alphabet = alphabet or "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	
	local lookup = {}
	for i = 1, #alphabet do
		lookup[alphabet:sub(i, i)] = i - 1
	end
	
	data = string.gsub(data, "[^" .. alphabet .. "=]", "")
	
	local result = ""
	local i = 1
	local value = 0
	local count = 0
	
	while i <= #data do
		local char = data:sub(i, i)
		local code = lookup[char]
		
		if code then
			value = value + code * (64 ^ (3 - count))
			count = count + 1
			
			if count == 4 then
				local b1 = math.floor(value / 65536)
				local b2 = math.floor((value % 65536) / 256)
				local b3 = value % 256
				
				result = result .. string.char(b1, b2, b3)
				value = 0
				count = 0
			end
		elseif char == "=" then
			if count > 1 then
				result = result .. string.char(math.floor(value / 65536))
				if count > 2 then
					result = result .. string.char(math.floor((value % 65536) / 256))
				end
			end
			break
		end
		
		i = i + 1
	end
	
	return result
end

function Base64.encode(data, alphabet)
	alphabet = alphabet or "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	
	local result = ""
	local i = 1
	
	while i <= #data do
		local b1 = string.byte(data, i)
		local b2 = string.byte(data, i + 1) or 0
		local b3 = string.byte(data, i + 2) or 0
		
		local value = b1 * 65536 + b2 * 256 + b3
		
		result = result .. alphabet:sub(math.floor(value / 262144) + 1, math.floor(value / 262144) + 1)
		result = result .. alphabet:sub(math.floor((value % 262144) / 4096) + 1, math.floor((value % 262144) / 4096) + 1)
		
		if i + 1 <= #data then
			result = result .. alphabet:sub(math.floor((value % 4096) / 64) + 1, math.floor((value % 4096) / 64) + 1)
		else
			result = result .. "="
		end
		
		if i + 2 <= #data then
			result = result .. alphabet:sub((value % 64) + 1, (value % 64) + 1)
		else
			result = result .. "="
		end
		
		i = i + 3
	end
	
	return result
end

return Base64
