#!/usr/bin/env lua

local Unwrap = require("src.core.layers.01-unwrap")
local SplitStrings = require("src.core.layers.02-split-strings")
local ConstantArray = require("src.core.layers.03-constant-array")
local DecryptStrings = require("src.core.layers.04-decrypt-strings")
local ProxifyLocals = require("src.core.layers.05-proxified")
local Vmify = require("src.core.layers.06-vmify")
local WeareDevs = require("src.core.layers.07-wearedevs")
local AntiTamper = require("src.core.layers.08-anti-tamper")
local NumberExpressions = require("src.core.layers.09-number-expressions")

local function print_usage()
        print("WeareDevs Deobfuscator CLI (Layers 1-9)")
        print("Usage: lua src/cli-wearedevs.lua <input_file> [options]")
        print()
        print("Options:")
        print("  --output FILE          Output file (default: input_wearedevs.lua)")
        print("  --keys K6,K7,K44,K8   PRNG keys for string decryption (comma-separated)")
        print("  --verbose              Show detailed progress")
        print("  --help                 Show this message")
        print()
end

local function parse_args(args)
        local input_file = nil
        local output_file = nil
        local keys = nil
        local verbose = false
        
        local i = 1
        while i <= #args do
                local arg = args[i]
                
                if arg == "--help" then
                        print_usage()
                        os.exit(0)
                elseif arg == "--output" then
                        i = i + 1
                        output_file = args[i]
                elseif arg == "--keys" then
                        i = i + 1
                        keys = args[i]
                elseif arg == "--verbose" then
                        verbose = true
                elseif not arg:match("^%-") then
                        input_file = arg
                end
                
                i = i + 1
        end
        
        return input_file, output_file, keys, verbose
end

local function parse_keys(keys_str)
        if not keys_str then
                return nil, nil, nil, nil
        end
        
        local parts = {}
        for part in string.gmatch(keys_str, "[^,]+") do
                table.insert(parts, tonumber(part))
        end
        
        if #parts == 4 then
                return parts[1], parts[2], parts[3], parts[4]
        end
        
        return nil, nil, nil, nil
end

local function deobfuscate_wearedevs(code)
        print("================================================================================")
        print("WEAREDEVS DEOBFUSCATOR (LAYERS 1-9)")
        print("================================================================================")
        print()
        
        local current_code = code
        
        -- Layer 1: Unwrap
        print("Layer 1: Unwrapping function wrappers...")
        local unwrapped, iterations = Unwrap.unwrap_all(current_code)
        if iterations > 0 then
                print("  ✓ Removed " .. iterations .. " wrapper layer(s)")
                current_code = unwrapped
        else
                print("  - No function wrappers found")
        end
        print()
        
        -- Layer 2: Split Strings
        print("Layer 2: Rejoining split strings...")
        local rejoined = SplitStrings.rejoin_all_fragments(current_code)
        if #current_code ~= #rejoined then
                print("  ✓ Rejoined split string fragments")
                current_code = rejoined
        else
                print("  - No split strings found")
        end
        print()
        
        -- Layer 3: Constant Array
        print("Layer 3: Decoding constant arrays...")
        local decoded, count = ConstantArray.process(current_code)
        if count > 0 then
                print("  ✓ Decoded " .. count .. " constant array(s)")
                current_code = decoded
        else
                print("  - No constant arrays found")
        end
        print()
        
        -- Layer 4: Decrypt Strings
        print("Layer 4: Decrypting strings...")
        local encrypted = DecryptStrings.find_encrypted_strings(current_code)
        if #encrypted > 0 then
                local results = DecryptStrings.find_keys_by_brute_force(encrypted, current_code)
                if #results > 0 then
                        local best = results[1]
                        local k6, k7, k44, k8 = unpack(best.keys)
                        print("  ✓ Auto-detected keys with " .. string.format("%.2f", best.confidence * 100) .. "% confidence")
                        
                        local decrypted, dec_count = DecryptStrings.decrypt_all(current_code, k6, k7, k44, k8)
                        if dec_count > 0 then
                                print("  ✓ Decrypted " .. dec_count .. " strings")
                                current_code = decrypted
                        end
                else
                        print("  - Could not auto-detect keys")
                end
        else
                print("  - No encrypted strings found")
        end
        print()
        
        -- Layer 5: Proxified Locals
        print("Layer 5: Reversing ProxifyLocals metatable indirection...")
        local reversed = ProxifyLocals.reverse_all(current_code)
        if reversed ~= current_code then
                print("  ✓ Reversed proxified locals")
                current_code = reversed
        else
                print("  - No proxified locals found")
        end
        print()
        
        -- Layer 6: Vmify
        print("Layer 6: Analyzing VM bytecode...")
        local analysis = Vmify.analyze(current_code)
        if analysis and analysis.is_vmified then
                print("  ✓ VM bytecode detected!")
                print("    Found " .. analysis.bytecode_arrays .. " bytecode array(s)")
                local extracted = Vmify.devirtualize(current_code)
                current_code = extracted
        else
                print("  - No VM bytecode detected")
        end
        print()
        
        -- Layer 7: WeareDevs
        print("Layer 7: Deobfuscating WeareDevs bytecode...")
        if WeareDevs.detect(current_code) then
                print("  ✓ WeareDevs obfuscation detected!")
                
                local array_name = WeareDevs.find_array_name(current_code)
                if array_name then
                        print("    Found bytecode array: " .. array_name)
                end
                
                local xor_keys = WeareDevs.detect_xor_key(current_code)
                if #xor_keys > 0 then
                        print("    Found XOR key(s): " .. table.concat(xor_keys, ", "))
                end
                
                local extracted = WeareDevs.extract_and_decode(current_code)
                if extracted and extracted ~= current_code then
                        current_code = extracted
                end
        else
                print("  - No WeareDevs obfuscation detected")
        end
        print()
        
        -- Layer 8: Anti-Tamper
        print("Layer 8: Removing anti-tamper checks...")
        if AntiTamper.detect(current_code) then
                local checks = AntiTamper.find_checks(current_code)
                print("  ✓ Found " .. #checks .. " anti-tamper check(s)")
                local cleaned = AntiTamper.reverse_all(current_code)
                if cleaned ~= current_code then
                        current_code = cleaned
                end
        else
                print("  - No anti-tamper code found")
        end
        print()
        
        -- Layer 9: Number Expressions
        print("Layer 9: Simplifying number expressions...")
        if NumberExpressions.detect(current_code) then
                print("  ✓ Number expressions detected")
                local simplified = NumberExpressions.reverse_all(current_code)
                if simplified ~= current_code then
                        current_code = simplified
                end
        else
                print("  - No number expressions found")
        end
        print()
        
        print("================================================================================")
        print("DEOBFUSCATION COMPLETE")
        print("================================================================================")
        print()
        print("Original size: " .. #code .. " bytes")
        print("Final size: " .. #current_code .. " bytes")
        print("Reduction: " .. math.floor((1 - (#current_code / #code)) * 100) .. "%")
        print()
        
        return current_code
end

local function main(...)
        local args = {...}
        
        if #args == 0 then
                print_usage()
                os.exit(1)
        end
        
        local input_file, output_file, keys_str, verbose = parse_args(args)
        
        if not input_file then
                print("ERROR: Input file not specified")
                print_usage()
                os.exit(1)
        end
        
        local file = io.open(input_file, "r")
        if not file then
                print("ERROR: Cannot open file: " .. input_file)
                os.exit(1)
        end
        
        local obfuscated_code = file:read("*a")
        file:close()
        
        local result = deobfuscate_wearedevs(obfuscated_code)
        
        if keys_str then
                local k6, k7, k44, k8 = parse_keys(keys_str)
                if k6 then
                        print()
                        print("Attempting string decryption with provided keys...")
                        result, _ = DecryptStrings.decrypt_all(result, k6, k7, k44, k8)
                end
        end
        
        output_file = output_file or input_file:gsub("%.lua$", "_wearedevs.lua")
        
        local out = io.open(output_file, "w")
        if not out then
                print("ERROR: Cannot write to: " .. output_file)
                os.exit(1)
        end
        
        out:write(result)
        out:close()
        
        print("✓ Deobfuscated code written to: " .. output_file)
        print()
end

main(...)
